sap.ui.define([
	"index_db/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
