/* global QUnit */

sap.ui.require(["indexdb/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
